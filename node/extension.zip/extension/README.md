# thebuttonchecker
Chrome extension to audibly alert users when the button is about to run out of time.
